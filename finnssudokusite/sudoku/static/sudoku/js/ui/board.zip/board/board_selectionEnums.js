
export const SelectionMode = {
    SINGLE: 'single',
    MULTIPLE: 'multiple',
};
