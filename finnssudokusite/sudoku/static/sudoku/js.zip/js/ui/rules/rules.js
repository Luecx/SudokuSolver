import {KropkiHandler} from "./rule_kropki.js";
import {StandardHandler} from "./rule_standard.js";
import {DiagonalHandler} from "./rule_diagonal.js";

// Add any new rule handlers here
export function createAllRuleHandlers(board) {
    return [
        new KropkiHandler(board),
        new StandardHandler(board),
        new DiagonalHandler(board)
        // Add more as needed
    ];
}
