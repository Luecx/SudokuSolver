import { RuleTypeHandler } from "./rule.js";

export class StandardHandler extends RuleTypeHandler {
    constructor(board) {
        super("Standard", board);
        this.tag = "standard";

        // Only one fixed rule instance, no adding/removing
        this.instanceConfig = {
            allowAddRemove: false,
            fixedInstances: [
                { type: "standard" }
            ]
        };
    }

    ui_generalRuleFields() {
        return [];
    }

    ui_specificRuleFields(rule) {
        return [];
    }

    ruleToText(rule) {
        return "Standard grid";
    }

    render(rule, ctx) {
        ctx.save();
        ctx.strokeStyle = "#000";
        ctx.lineWidth = 2;

        const gridSize = this.board.getGridSize?.() ?? 9;

        // Bold horizontal lines
        for (let row = 3; row < gridSize; row += 3) {
            const { y } = this.board.getCellTopLeft(row, 0);
            const { x: xStart } = this.board.getCellTopLeft(0, 0);
            const { x: xEnd } = this.board.getCellTopLeft(0, gridSize);
            ctx.beginPath();
            ctx.moveTo(xStart, y);
            ctx.lineTo(xEnd, y);
            ctx.stroke();
        }

        // Bold vertical lines
        for (let col = 3; col < gridSize; col += 3) {
            const { x } = this.board.getCellTopLeft(0, col);
            const { y: yStart } = this.board.getCellTopLeft(0, 0);
            const { y: yEnd } = this.board.getCellTopLeft(gridSize, 0);
            ctx.beginPath();
            ctx.moveTo(x, yStart);
            ctx.lineTo(x, yEnd);
            ctx.stroke();
        }

        ctx.restore();
    }
}
