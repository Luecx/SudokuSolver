import { RuleTypeHandler } from "./rule.js";

export class DiagonalHandler extends RuleTypeHandler {
    constructor(board) {
        super("Diagonal", board);
        this.tag = "diagonal";

        this.instanceConfig = {
            allowAddRemove: false,
            fixedInstances: [
                { type: "diag-a" },
                { type: "diag-b" }
            ]
        };
    }

    ui_generalRuleFields() {
        const makeCheckbox = (label, type) => {
            return {
                type: "boolean",
                label,
                defaultValue: true,
                onDone: ({ value }) => {
                    const rule = this.rules.find(r => r.type === type);
                    rule.disabled = !value;
                    this.board.render();
                },
                getData: () => {
                    const rule = this.rules.find(r => r.type === type);
                    return { value: !(rule?.disabled ?? false) };
                }
            };
        };

        return [
            makeCheckbox("Main diagonal", "diag-a"),
            makeCheckbox("Anti-diagonal", "diag-b")
        ];
    }

    ui_specificRuleFields(rule) {
        return [];
    }

    ruleToText(rule) {
        if (rule.type === "diag-a") return "Main diagonal";
        if (rule.type === "diag-b") return "Anti-diagonal";
        return "";
    }

    render(rule, ctx) {
        if (rule.disabled) return;

        const cellSize = this.board.getCellSize();
        const offset = cellSize / 2;

        ctx.save();
        ctx.strokeStyle = "#00f";
        ctx.lineWidth = 2;

        const gridSize = this.board.getGridSize?.() ?? 9;
        const last = gridSize - 1;

        if (rule.type === "diag-a") {
            const topLeft = this.board.getCellTopLeft(0, 0);
            const bottomRight = this.board.getCellTopLeft(last, last);

            ctx.beginPath();
            ctx.moveTo(topLeft.x + offset, topLeft.y + offset);
            ctx.lineTo(bottomRight.x + offset, bottomRight.y + offset);
            ctx.stroke();
        }

        if (rule.type === "diag-b") {
            const bottomLeft = this.board.getCellTopLeft(last, 0);
            const topRight = this.board.getCellTopLeft(0, last);

            ctx.beginPath();
            ctx.moveTo(bottomLeft.x + offset, bottomLeft.y + offset);
            ctx.lineTo(topRight.x + offset, topRight.y + offset);
            ctx.stroke();
        }

        ctx.restore();
    }
}
