export const RegionType = {
    NONE: 'none',
    CELLS: 'cells',
    EDGES: 'edges',
    CORNERS: 'corners',
};
